# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## 2025-12-18

### Fixed

- Prevent screenshot stretching in Safari in `sections/hero-with-demo-on-background.tsx`
- Move log in button to menu at smallest screen size

## 2025-12-18

### Added

- Initial release
